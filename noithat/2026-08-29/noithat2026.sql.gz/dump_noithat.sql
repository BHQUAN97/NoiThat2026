-- MySQL dump 10.13  Distrib 8.4.11, for Linux (x86_64)
--
-- Host: localhost    Database: noithat2026
-- ------------------------------------------------------
-- Server version	8.4.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_logs`
--

DROP TABLE IF EXISTS `app_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_logs` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` enum('error','warn','info','debug','trace') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info',
  `message` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stack_trace` text COLLATE utf8mb4_unicode_ci,
  `endpoint` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_code` smallint DEFAULT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` char(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `context` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IDX_app_logs_level` (`level`),
  KEY `IDX_app_logs_created_at` (`created_at`),
  KEY `IDX_app_logs_level_created_at` (`level`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_logs`
--

LOCK TABLES `app_logs` WRITE;
/*!40000 ALTER TABLE `app_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_submissions`
--

DROP TABLE IF EXISTS `form_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_submissions` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `form_type` enum('quote','contact') COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` json DEFAULT NULL,
  `status` enum('new','processing','done') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IDX_form_submissions_status` (`status`),
  KEY `IDX_form_submissions_type` (`form_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_submissions`
--

LOCK TABLES `form_submissions` WRITE;
/*!40000 ALTER TABLE `form_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `success` tinyint(1) NOT NULL DEFAULT '0',
  `attempted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IDX_login_attempts_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
INSERT INTO `login_attempts` VALUES (1,'::ffff:172.19.0.4','admin@duymanhnoithat.vn',1,'2026-08-29 08:19:17');
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int unsigned NOT NULL,
  `original_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preview_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `alt_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blurhash` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processing_status` enum('pending','processing','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `processing_error` text COLLATE utf8mb4_unicode_ci,
  `uploaded_by` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_media_uploaded_by` (`uploaded_by`),
  KEY `IDX_media_processing_status` (`processing_status`),
  KEY `IDX_media_deleted_at` (`deleted_at`),
  CONSTRAINT `FK_media_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` bigint NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,1749200000000,'NoiThat2026InitialSchema1749200000000'),(2,1749400000000,'AddLogsAnalyticsPages1749400000000'),(3,1750600000000,'AddPricingDetailUrl1750600000000');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `thumbnail_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `published_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_news_slug` (`slug`),
  KEY `IDX_news_active` (`is_active`,`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES ('01M167S5Q6227Z7P0P76DQYAJS','Nên chọn Acrylic hay Laminate cho tủ bếp gia đình?','nen-chon-acrylic-hay-laminate-cho-tu-bep-gia-dinh','So sánh thực tế về độ bền, khả năng vệ sinh, thẩm mỹ và ngân sách khi làm tủ bếp.','Acrylic tạo bề mặt bóng sâu, hợp căn hộ hiện đại và dễ lau dầu mỡ. Điểm cần lưu ý là bề mặt bóng dễ lộ vết xước dăm nếu dùng khăn cứng.\n\nLaminate có lợi thế chống xước tốt, nhiều mã vân gỗ và màu trơn. Với gia đình nấu ăn nhiều hoặc nhà cho thuê, Laminate thường là lựa chọn an toàn hơn.\n\nCách chọn thực tế là dùng Acrylic cho mảng trên hoặc điểm nhấn, Laminate cho khu vực chịu va chạm nhiều. Đội Duy Mạnh thường tư vấn theo tần suất nấu và ngân sách hoàn thiện.','https://picsum.photos/seed/N%C3%AAn%20ch%E1%BB%8Dn%20Acrylic%20hay%20Laminate%20cho%20t%E1%BB%A7%20b%E1%BA%BFp%20gia%20%C4%91%C3%ACnh%3F/800/600',1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5QDWYMF1T783RTBWQA2','Checklist đo hiện trạng trước khi đóng nội thất','checklist-do-hien-trang-truoc-khi-dong-noi-that','Những vị trí phải đo kỹ để tránh tủ vướng ổ điện, cửa mở hoặc dầm trần.','Bản đo hiện trạng cần có chiều dài, rộng, cao từng phòng, vị trí cửa, cửa sổ, dầm, cột, hộp kỹ thuật và ổ điện.\n\nRiêng khu bếp phải kiểm tra đường cấp thoát nước, vị trí máy hút mùi, ổ cắm bếp từ, máy rửa bát và chiều cao trần sau khi hoàn thiện.\n\nNên chụp ảnh toàn bộ mặt bằng kèm video quét chậm từng góc. Việc này giúp xưởng giảm sai số khi lên bản vẽ sản xuất.','https://picsum.photos/seed/Checklist%20%C4%91o%20hi%E1%BB%87n%20tr%E1%BA%A1ng%20tr%C6%B0%E1%BB%9Bc%20khi%20%C4%91%C3%B3ng%20n%E1%BB%99i%20th%E1%BA%A5t/800/600',1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5QNP0388TRV481YG2NX','Làm nội thất căn hộ 2PN cần ngân sách bao nhiêu?','lam-noi-that-can-ho-2pn-can-ngan-sach-bao-nhieu','Khoảng giá tham khảo theo ba mức: tiết kiệm, tiêu chuẩn và cao cấp.','Với căn hộ 55-75m2, gói tiết kiệm thường nằm trong khoảng 145-180 triệu đồng nếu dùng Melamine và phụ kiện cơ bản.\n\nGói tiêu chuẩn dùng MDF chống ẩm, Laminate/Acrylic cho bếp và tủ áo tốt hơn thường nằm trong khoảng 190-260 triệu đồng.\n\nNgân sách cao cấp có thể vượt 300 triệu đồng khi dùng nhiều gỗ tự nhiên, đá bếp tốt, phụ kiện Hafele/Blum và đồ rời đồng bộ.','https://picsum.photos/seed/L%C3%A0m%20n%E1%BB%99i%20th%E1%BA%A5t%20c%C4%83n%20h%E1%BB%99%202PN%20c%E1%BA%A7n%20ng%C3%A2n%20s%C3%A1ch%20bao%20nhi%C3%AAu%3F/800/600',1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5QVWRV79RTE2VYK1YDD','Cách chọn phụ kiện bếp để không phải sửa sau 2 năm','cach-chon-phu-kien-bep-de-khong-phai-sua-sau-2-nam','Ray, bản lề, giá xoong nồi và tay nâng nên chọn theo tải trọng thay vì chỉ nhìn giá.','Phụ kiện bếp là phần vận hành mỗi ngày nên cần chọn theo tải trọng khoang tủ. Giá xoong nồi, ray hộp và tay nâng phải tương thích kích thước tủ.\n\nNếu ngân sách giới hạn, nên ưu tiên bản lề giảm chấn, ray ngăn kéo và giá xoong nồi trước. Các phụ kiện ít dùng có thể nâng cấp sau.\n\nTrước khi lắp, thợ cần kiểm tra độ vuông khoang và độ chắc của vách tủ để phụ kiện chạy êm lâu dài.','https://picsum.photos/seed/C%C3%A1ch%20ch%E1%BB%8Dn%20ph%E1%BB%A5%20ki%E1%BB%87n%20b%E1%BA%BFp%20%C4%91%E1%BB%83%20kh%C3%B4ng%20ph%E1%BA%A3i%20s%E1%BB%ADa%20sau%202%20n%C4%83m/800/600',1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5R11TY1NDJ6RFJ1ZR08','Vật liệu nào phù hợp cho nội thất văn phòng?','vat-lieu-nao-phu-hop-cho-noi-that-van-phong','MFC, MDF, khung sắt và laminate nên dùng ở đâu để bền và dễ bảo trì.','Văn phòng có tần suất sử dụng cao nên mặt bàn cần chống trầy, dễ lau và thay thế được theo module. MFC phủ Melamine là lựa chọn kinh tế cho bàn làm việc số lượng lớn.\n\nKhu vực tiếp khách, phòng họp hoặc phòng giám đốc có thể nâng cấp Laminate, veneer hoặc đá nhân tạo để tăng nhận diện thương hiệu.\n\nKhung sắt sơn tĩnh điện giúp bàn dài vững hơn, đặc biệt với cụm bàn nhiều người và hệ máng điện.','https://picsum.photos/seed/V%E1%BA%ADt%20li%E1%BB%87u%20n%C3%A0o%20ph%C3%B9%20h%E1%BB%A3p%20cho%20n%E1%BB%99i%20th%E1%BA%A5t%20v%C4%83n%20ph%C3%B2ng%3F/800/600',1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08','2026-08-29 07:47:08');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `link` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IDX_notifications_user_id` (`user_id`),
  KEY `IDX_notifications_is_read` (`is_read`),
  KEY `IDX_notifications_created_at` (`created_at`),
  CONSTRAINT `FK_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_config_history`
--

DROP TABLE IF EXISTS `page_config_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_config_history` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_config_id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_snapshot` json NOT NULL,
  `version` int unsigned NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `published_by` char(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IDX_pch_page_config_id` (`page_config_id`),
  CONSTRAINT `FK_pch_page_config` FOREIGN KEY (`page_config_id`) REFERENCES `page_configs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_config_history`
--

LOCK TABLES `page_config_history` WRITE;
/*!40000 ALTER TABLE `page_config_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_config_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_configs`
--

DROP TABLE IF EXISTS `page_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_configs` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_draft` json DEFAULT NULL,
  `config_published` json DEFAULT NULL,
  `version` int unsigned NOT NULL DEFAULT '0',
  `published_at` timestamp NULL DEFAULT NULL,
  `published_by` char(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` char(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_page_configs_slug` (`page_slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_configs`
--

LOCK TABLES `page_configs` WRITE;
/*!40000 ALTER TABLE `page_configs` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_view_daily`
--

DROP TABLE IF EXISTS `page_view_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_view_daily` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `page_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_date` date NOT NULL,
  `total_views` int unsigned NOT NULL DEFAULT '0',
  `unique_visitors` int unsigned NOT NULL DEFAULT '0',
  `mobile_views` int unsigned NOT NULL DEFAULT '0',
  `desktop_views` int unsigned NOT NULL DEFAULT '0',
  `tablet_views` int unsigned NOT NULL DEFAULT '0',
  `bot_views` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_page_view_daily_path_date` (`page_path`(191),`view_date`),
  KEY `IDX_page_view_daily_date` (`view_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_view_daily`
--

LOCK TABLES `page_view_daily` WRITE;
/*!40000 ALTER TABLE `page_view_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_view_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_views`
--

DROP TABLE IF EXISTS `page_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_views` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `page_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visitor_ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `referrer` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` enum('desktop','mobile','tablet') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_bot` tinyint(1) NOT NULL DEFAULT '0',
  `session_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `viewed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`viewed_at`),
  KEY `IDX_page_views_page_path` (`page_path`(191)),
  KEY `IDX_page_views_viewed_at` (`viewed_at`),
  KEY `IDX_page_views_session_id` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
/*!50100 PARTITION BY RANGE (unix_timestamp(`viewed_at`))
(PARTITION p2026_q1 VALUES LESS THAN (1775001600) ENGINE = InnoDB,
 PARTITION p2026_q2 VALUES LESS THAN (1782864000) ENGINE = InnoDB,
 PARTITION p2026_q3 VALUES LESS THAN (1790812800) ENGINE = InnoDB,
 PARTITION p2026_q4 VALUES LESS THAN (1798761600) ENGINE = InnoDB,
 PARTITION p_future VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_views`
--

LOCK TABLES `page_views` WRITE;
/*!40000 ALTER TABLE `page_views` DISABLE KEYS */;
INSERT INTO `page_views` VALUES (1,'/','113.190.92.129','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36',NULL,'desktop',0,NULL,'2026-08-29 08:19:09'),(2,'/','2.56.18.185','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1',NULL,'mobile',0,NULL,'2026-08-29 08:27:29'),(3,'/','59.153.237.77','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/151.0.7922.112 Mobile/15E148 Safari/604.1',NULL,'mobile',0,NULL,'2026-08-29 11:10:28'),(4,'/','59.153.237.77','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/151.0.7922.112 Mobile/15E148 Safari/604.1',NULL,'mobile',0,NULL,'2026-08-29 11:40:50'),(5,'/','59.153.237.77','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/151.0.7922.112 Mobile/15E148 Safari/604.1',NULL,'mobile',0,NULL,'2026-08-29 11:40:51'),(6,'/','42.117.10.6','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1',NULL,'mobile',0,NULL,'2026-08-29 11:40:56'),(7,'/','59.153.237.77','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/151.0.7922.112 Mobile/15E148 Safari/604.1',NULL,'mobile',0,NULL,'2026-08-29 12:27:21'),(8,'/','59.153.237.77','Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/151.0.7922.112 Mobile/15E148 Safari/604.1',NULL,'mobile',0,NULL,'2026-08-29 13:11:52');
/*!40000 ALTER TABLE `page_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IDX_prt_user` (`user_id`),
  CONSTRAINT `FK_prt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pricing_tables`
--

DROP TABLE IF EXISTS `pricing_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pricing_tables` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `items` json DEFAULT NULL,
  `detail_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pricing_tables`
--

LOCK TABLES `pricing_tables` WRITE;
/*!40000 ALTER TABLE `pricing_tables` DISABLE KEYS */;
INSERT INTO `pricing_tables` VALUES ('01M167S5NZC8N3B9S9CHCK08CM','Gói Căn Hộ Tiết Kiệm','Phù hợp căn hộ 1-2PN cần nội thất cơ bản, dễ bảo trì.','[{\"unit\": \"md\", \"label\": \"Tủ bếp MDF Melamine\", \"price\": \"2.800.000 - 3.600.000\"}, {\"unit\": \"m2 mặt cánh\", \"label\": \"Tủ áo cánh mở\", \"price\": \"2.400.000 - 3.200.000\"}, {\"unit\": \"bộ\", \"label\": \"Kệ TV treo\", \"price\": \"5.500.000 - 9.000.000\"}]',NULL,1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5P75ZE3B8SKK0EVEK9K','Gói Gia Đình Cao Cấp','Dùng MDF chống ẩm, Laminate/Acrylic và phụ kiện giảm chấn đồng bộ.','[{\"unit\": \"md\", \"label\": \"Tủ bếp Acrylic/Laminate\", \"price\": \"4.200.000 - 6.500.000\"}, {\"unit\": \"m2 mặt cánh\", \"label\": \"Tủ áo cánh lùa\", \"price\": \"3.600.000 - 5.200.000\"}, {\"unit\": \"bộ\", \"label\": \"Giường hộp lưu trữ\", \"price\": \"12.000.000 - 22.000.000\"}]',NULL,2,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5PDHAYKSM7DJYCWTVQJ','Gói Gỗ Tự Nhiên','Cho nhà phố, biệt thự hoặc khách hàng ưu tiên độ bền và vân gỗ thật.','[{\"unit\": \"md\", \"label\": \"Tủ bếp gỗ Sồi\", \"price\": \"6.800.000 - 8.500.000\"}, {\"unit\": \"bộ\", \"label\": \"Tủ thờ gỗ tự nhiên\", \"price\": \"14.000.000 - 45.000.000\"}, {\"unit\": \"m2\", \"label\": \"Ốp vách gỗ\", \"price\": \"2.800.000 - 5.500.000\"}]',NULL,3,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5PK5MP1SHVX8SNZHQX4','Gói Văn Phòng','Bàn ghế, tủ hồ sơ, phòng họp và pantry cho doanh nghiệp nhỏ đến vừa.','[{\"unit\": \"chỗ\", \"label\": \"Cụm bàn làm việc\", \"price\": \"2.600.000 - 4.200.000\"}, {\"unit\": \"m2\", \"label\": \"Tủ hồ sơ kịch trần\", \"price\": \"2.400.000 - 3.600.000\"}, {\"unit\": \"bộ\", \"label\": \"Bàn họp 8-12 người\", \"price\": \"12.000.000 - 28.000.000\"}]',NULL,4,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5Q0722HQZHM3YAHKYKP','Gói F&B - Khách Sạn','Nội thất chịu tần suất sử dụng cao cho nhà hàng, cafe, homestay, khách sạn.','[{\"unit\": \"ghế\", \"label\": \"Ghế nhà hàng\", \"price\": \"1.450.000 - 3.200.000\"}, {\"unit\": \"bàn\", \"label\": \"Bàn nhà hàng\", \"price\": \"2.200.000 - 6.800.000\"}, {\"unit\": \"bộ\", \"label\": \"Quầy thu ngân/bar\", \"price\": \"18.000.000 - 65.000.000\"}]',NULL,5,1,'2026-08-29 07:47:08','2026-08-29 07:47:08');
/*!40000 ALTER TABLE `pricing_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_categories`
--

DROP TABLE IF EXISTS `product_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_categories` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `thumbnail_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_product_categories_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_categories`
--

LOCK TABLES `product_categories` WRITE;
/*!40000 ALTER TABLE `product_categories` DISABLE KEYS */;
INSERT INTO `product_categories` VALUES ('01M167S5CCD54HDWHZPQVKSDVZ','Tủ bếp','tu-bep','Tủ bếp gỗ công nghiệp, gỗ tự nhiên và hệ phụ kiện bếp theo kích thước thực tế.','https://picsum.photos/seed/modern%20kitchen%20cabinet/800/600',1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5CJGX3SXC2TZPQGAP7Z','Phòng khách','phong-khach','Sofa, kệ TV, vách trang trí và hệ lưu trữ cho không gian tiếp khách gia đình.','https://picsum.photos/seed/modern%20living%20room%20furniture/800/600',2,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5CTMJJEX1HSC74DS38X','Phòng ngủ','phong-ngu','Giường, tủ áo, bàn trang điểm và giải pháp lưu trữ tối ưu cho phòng ngủ.','https://picsum.photos/seed/bedroom%20wardrobe%20interior/800/600',3,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5D1VFKSEQAGF9M7WB1X','Phòng trẻ em','phong-tre-em','Giường tầng, bàn học, tủ đồ an toàn và linh hoạt theo từng độ tuổi.','https://picsum.photos/seed/kids%20room%20furniture/800/600',4,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5D74HQ6Q4M2G8ZQHN0A','Văn phòng','van-phong','Bàn làm việc, module lưu trữ, phòng họp và pantry cho doanh nghiệp.','https://picsum.photos/seed/office%20interior%20furniture/800/600',5,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5DE0T9M3B9EDX3TKXVN','Nhà hàng - khách sạn','nha-hang-khach-san','Nội thất F&B, khách sạn, homestay và không gian dịch vụ có tần suất sử dụng cao.','https://picsum.photos/seed/hotel%20restaurant%20interior/800/600',6,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5DMVQYXC4FP6BC3PQCN','Showroom - cửa hàng','showroom-cua-hang','Quầy kệ trưng bày, tủ hàng, quầy thu ngân và hệ nhận diện không gian bán lẻ.','https://picsum.photos/seed/retail%20showroom%20interior/800/600',7,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5DV5D12D11X43VY0480','Phòng thờ','phong-tho','Tủ thờ, vách thờ, bàn thờ treo và không gian thờ tự trang nghiêm.','https://picsum.photos/seed/wood%20altar%20room%20interior/800/600',8,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5E1GY0F3WFJPSE0KHRF','Phụ kiện - thiết bị','phu-kien-thiet-bi','Ray trượt, bản lề, tay nâng, đèn LED, đá bếp và phụ kiện hoàn thiện.','https://picsum.photos/seed/cabinet%20hardware%20interior/800/600',9,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5E7VZHC4427MTTCHZT1','Nội thất trọn gói','noi-that-tron-goi','Gói thiết kế, sản xuất và thi công đồng bộ cho căn hộ, nhà phố, biệt thự.','https://picsum.photos/seed/full%20home%20interior/800/600',10,1,'2026-08-29 07:47:08','2026-08-29 07:47:08');
/*!40000 ALTER TABLE `product_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `thumbnail_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gallery_urls` json DEFAULT NULL,
  `specs` json DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_products_slug` (`slug`),
  KEY `IDX_products_category` (`category_id`),
  CONSTRAINT `FK_products_category` FOREIGN KEY (`category_id`) REFERENCES `product_categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES ('01M167S5EHYVDVWPF4MQE3J6JD','Tủ bếp chữ L MDF chống ẩm phủ Acrylic','tu-bep-chu-l-mdf-chong-am-phu-acrylic','01M167S5CCD54HDWHZPQVKSDVZ','Giải pháp tủ bếp hiện đại cho căn hộ 70-100m2, bề mặt bóng gương dễ vệ sinh.','Hệ tủ dưới dùng MDF lõi xanh chống ẩm, thùng tủ phủ Melamine hai mặt, cánh Acrylic không đường line cạnh. Thiết kế chữ L giúp tối ưu tam giác bếp và tạo thêm mặt bàn thao tác.\n\nBộ phụ kiện khuyến nghị gồm bản lề giảm chấn, ray hộp, giá xoong nồi, thùng gạo âm và hệ đèn LED dưới tủ trên. Phù hợp gia đình 3-5 người nấu ăn hằng ngày.','https://picsum.photos/seed/white%20acrylic%20kitchen%20cabinet/800/600','[\"https://picsum.photos/seed/white%20acrylic%20kitchen%20cabinet/800/600\", \"https://picsum.photos/seed/T%E1%BB%A7%20b%E1%BA%BFp%20ch%E1%BB%AF%20L%20MDF%20ch%E1%BB%91ng%20%E1%BA%A9m%20ph%E1%BB%A7%20Acrylic%20detail/800/600\", \"https://picsum.photos/seed/T%E1%BB%A7%20b%E1%BA%BFp%20ch%E1%BB%AF%20L%20MDF%20ch%E1%BB%91ng%20%E1%BA%A9m%20ph%E1%BB%A7%20Acrylic%20showroom/800/600\"]','{\"Bảo hành\": \"24 tháng\", \"Vật liệu\": \"MDF lõi xanh chống ẩm, Acrylic An Cường\", \"Đơn giá tham khảo\": \"4.200.000 - 5.800.000 đ/md\", \"Thời gian sản xuất\": \"15 - 20 ngày\"}',1,1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5EQNSN879JS6CCN9GB8','Tủ bếp gỗ Sồi Nga sơn Inchem','tu-bep-go-soi-nga-son-inchem','01M167S5CCD54HDWHZPQVKSDVZ','Tủ bếp gỗ tự nhiên cho nhà phố và biệt thự thích vân gỗ ấm.','Gỗ Sồi Nga đã tẩm sấy, xử lý chống cong vênh và sơn Inchem giữ vân tự nhiên. Kiểu dáng phù hợp các không gian bán cổ điển, Indochine nhẹ hoặc nhà vườn.\n\nCấu hình có thể kết hợp mặt đá thạch anh, kính ốp bếp cường lực và phụ kiện Hafele/Eurogold tùy ngân sách.','https://picsum.photos/seed/oak%20wood%20kitchen%20cabinet/800/600','[\"https://picsum.photos/seed/oak%20wood%20kitchen%20cabinet/800/600\", \"https://picsum.photos/seed/T%E1%BB%A7%20b%E1%BA%BFp%20g%E1%BB%97%20S%E1%BB%93i%20Nga%20s%C6%A1n%20Inchem%20detail/800/600\", \"https://picsum.photos/seed/T%E1%BB%A7%20b%E1%BA%BFp%20g%E1%BB%97%20S%E1%BB%93i%20Nga%20s%C6%A1n%20Inchem%20showroom/800/600\"]','{\"Bề mặt\": \"Sơn Inchem mờ 35%\", \"Bảo hành\": \"36 tháng\", \"Vật liệu\": \"Gỗ Sồi Nga tự nhiên\", \"Đơn giá tham khảo\": \"6.800.000 - 8.500.000 đ/md\"}',2,1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5EXJCDXQZX66DTJ3HT4','Tủ bếp Laminate chống xước cho nhà cho thuê','tu-bep-laminate-chong-xuoc-cho-nha-cho-thue','01M167S5CCD54HDWHZPQVKSDVZ','Cấu hình bền, dễ bảo trì, hợp căn hộ dịch vụ và nhà cho thuê dài hạn.','Bề mặt Laminate chịu xước tốt hơn Melamine thông thường, màu vân gỗ hoặc màu trơn trung tính giúp ít lỗi thời. Thùng tủ bố trí modul tiêu chuẩn để dễ thay thế cánh, ray hoặc phụ kiện.\n\nPhù hợp chủ đầu tư cần kiểm soát chi phí nhưng vẫn muốn sản phẩm dùng ổn định trong môi trường khai thác liên tục.','https://picsum.photos/seed/laminate%20kitchen%20cabinet/800/600','[\"https://picsum.photos/seed/laminate%20kitchen%20cabinet/800/600\", \"https://picsum.photos/seed/T%E1%BB%A7%20b%E1%BA%BFp%20Laminate%20ch%E1%BB%91ng%20x%C6%B0%E1%BB%9Bc%20cho%20nh%C3%A0%20cho%20thu%C3%AA%20detail/800/600\", \"https://picsum.photos/seed/T%E1%BB%A7%20b%E1%BA%BFp%20Laminate%20ch%E1%BB%91ng%20x%C6%B0%E1%BB%9Bc%20cho%20nh%C3%A0%20cho%20thu%C3%AA%20showroom/800/600\"]','{\"Bảo trì\": \"Dễ thay cánh theo module\", \"Vật liệu\": \"MDF chống ẩm phủ Laminate\", \"Nhóm khách hàng\": \"Căn hộ cho thuê, homestay\", \"Đơn giá tham khảo\": \"3.600.000 - 4.900.000 đ/md\"}',3,1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5F42FT2JJJKBS415QJP','Kệ TV treo tường kết hợp tủ trang trí','ke-tv-treo-tuong-ket-hop-tu-trang-tri','01M167S5CJGX3SXC2TZPQGAP7Z','Kệ TV gọn sàn, đi dây âm và có khoang trưng bày cho phòng khách nhỏ.','Thiết kế treo tường giúp sàn thoáng, robot hút bụi hoạt động dễ hơn. Phần tủ cao có khoang kính, đèn LED và ngăn kín để giấu đồ dùng ít đẹp mắt.\n\nKích thước, màu sắc và tỷ lệ mảng đặc-rỗng được đo theo đúng vị trí TV, ổ điện và chiều rộng sofa.','https://picsum.photos/seed/floating%20tv%20cabinet%20living%20room/800/600','[\"https://picsum.photos/seed/floating%20tv%20cabinet%20living%20room/800/600\", \"https://picsum.photos/seed/K%E1%BB%87%20TV%20treo%20t%C6%B0%E1%BB%9Dng%20k%E1%BA%BFt%20h%E1%BB%A3p%20t%E1%BB%A7%20trang%20tr%C3%AD%20detail/800/600\", \"https://picsum.photos/seed/K%E1%BB%87%20TV%20treo%20t%C6%B0%E1%BB%9Dng%20k%E1%BA%BFt%20h%E1%BB%A3p%20t%E1%BB%A7%20trang%20tr%C3%AD%20showroom/800/600\"]','{\"Phụ kiện\": \"Ray bi giảm chấn, LED hắt\", \"Vật liệu\": \"MDF chống ẩm phủ Melamine hoặc Laminate\", \"Đơn giá tham khảo\": \"8.500.000 - 18.000.000 đ/bộ\", \"Kích thước phổ biến\": \"2.4m - 3.2m\"}',4,1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5FAY27627JYQY2PQKAE','Vách ốp sau sofa nano vân gỗ','vach-op-sau-sofa-nano-van-go','01M167S5CJGX3SXC2TZPQGAP7Z','Tạo điểm nhấn ấm cho phòng khách mà không phải thi công gỗ tự nhiên nặng chi phí.','Vách nano vân gỗ kết hợp chỉ inox hoặc lam sóng giúp xử lý mảng tường trống sau sofa. Vật liệu nhẹ, thi công nhanh và dễ bảo trì trong căn hộ đã ở.\n\nCó thể tích hợp đèn hắt, tranh treo hoặc module tủ mỏng để tăng công năng.','https://picsum.photos/seed/wood%20wall%20panel%20living%20room/800/600','[\"https://picsum.photos/seed/wood%20wall%20panel%20living%20room/800/600\", \"https://picsum.photos/seed/V%C3%A1ch%20%E1%BB%91p%20sau%20sofa%20nano%20v%C3%A2n%20g%E1%BB%97%20detail/800/600\", \"https://picsum.photos/seed/V%C3%A1ch%20%E1%BB%91p%20sau%20sofa%20nano%20v%C3%A2n%20g%E1%BB%97%20showroom/800/600\"]','{\"Vật liệu\": \"Tấm nano, lam nhựa giả gỗ, chỉ inox\", \"Ứng dụng\": \"Căn hộ, nhà phố, văn phòng nhỏ\", \"Thời gian thi công\": \"1 - 2 ngày\", \"Đơn giá tham khảo\": \"1.150.000 - 1.850.000 đ/m2\"}',5,1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5FHR2R9BD562WRBB8AX','Tủ áo cánh lùa kịch trần','tu-ao-canh-lua-kich-tran','01M167S5CTMJJEX1HSC74DS38X','Tối ưu lối đi phòng ngủ hẹp, chia khoang theo thói quen sử dụng thực tế.','Cánh lùa giúp không cần khoảng mở cánh trước tủ, đặc biệt hợp phòng ngủ căn hộ. Bên trong chia khoang treo dài, treo ngắn, ngăn kéo phụ kiện, hộc vali và đèn cảm biến.\n\nRay lùa giảm chấn được chọn theo trọng lượng cánh để hạn chế xệ cánh sau thời gian dài sử dụng.','https://picsum.photos/seed/sliding%20wardrobe%20bedroom/800/600','[\"https://picsum.photos/seed/sliding%20wardrobe%20bedroom/800/600\", \"https://picsum.photos/seed/T%E1%BB%A7%20%C3%A1o%20c%C3%A1nh%20l%C3%B9a%20k%E1%BB%8Bch%20tr%E1%BA%A7n%20detail/800/600\", \"https://picsum.photos/seed/T%E1%BB%A7%20%C3%A1o%20c%C3%A1nh%20l%C3%B9a%20k%E1%BB%8Bch%20tr%E1%BA%A7n%20showroom/800/600\"]','{\"Chiều cao\": \"Kịch trần theo hiện trạng\", \"Phụ kiện\": \"Ray lùa giảm chấn, đèn cảm biến\", \"Vật liệu\": \"MDF chống ẩm phủ Melamine/Laminate\", \"Đơn giá tham khảo\": \"3.200.000 - 4.800.000 đ/m2 mặt cánh\"}',6,1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5FQ4RZC4GYS0CYXC7DZ','Giường hộp có ngăn kéo lưu trữ','giuong-hop-co-ngan-keo-luu-tru','01M167S5CTMJJEX1HSC74DS38X','Giường ngủ tích hợp kho đồ cho phòng nhỏ hoặc gia đình có nhiều chăn ga.','Khung giường dạng hộp vững, hộc kéo hai bên hoặc cuối giường tùy mặt bằng. Thiết kế đầu giường có thể bọc nệm, ốp gỗ hoặc tích hợp tab liền khối.\n\nSản phẩm được đo theo kích thước nệm thực tế, ổ cắm đầu giường và khoảng mở hộc kéo.','https://picsum.photos/seed/storage%20bed%20bedroom/800/600','[\"https://picsum.photos/seed/storage%20bed%20bedroom/800/600\", \"https://picsum.photos/seed/Gi%C6%B0%E1%BB%9Dng%20h%E1%BB%99p%20c%C3%B3%20ng%C4%83n%20k%C3%A9o%20l%C6%B0u%20tr%E1%BB%AF%20detail/800/600\", \"https://picsum.photos/seed/Gi%C6%B0%E1%BB%9Dng%20h%E1%BB%99p%20c%C3%B3%20ng%C4%83n%20k%C3%A9o%20l%C6%B0u%20tr%E1%BB%AF%20showroom/800/600\"]','{\"Công năng\": \"2 - 4 ngăn kéo lưu trữ\", \"Vật liệu\": \"MDF chống ẩm, khung gia cường\", \"Kích thước nệm\": \"1.6x2m hoặc 1.8x2m\", \"Đơn giá tham khảo\": \"9.500.000 - 18.000.000 đ/bộ\"}',7,1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5FY6GGMYYP2D03F2D3P','Giường tầng trẻ em tích hợp bàn học','giuong-tang-tre-em-tich-hop-ban-hoc','01M167S5D1VFKSEQAGF9M7WB1X','Cụm giường, tủ áo và bàn học tiết kiệm diện tích cho phòng 8-12m2.','Thiết kế ưu tiên bo góc, lan can cao, bậc thang có tay vịn và vật liệu phát thải thấp. Bàn học đặt gần nguồn sáng tự nhiên, có kệ sách và bảng ghim.\n\nModule tủ dưới cầu thang tận dụng cho đồ chơi, cặp sách và chăn ga.','https://picsum.photos/seed/kids%20bunk%20bed%20study%20desk/800/600','[\"https://picsum.photos/seed/kids%20bunk%20bed%20study%20desk/800/600\", \"https://picsum.photos/seed/Gi%C6%B0%E1%BB%9Dng%20t%E1%BA%A7ng%20tr%E1%BA%BB%20em%20t%C3%ADch%20h%E1%BB%A3p%20b%C3%A0n%20h%E1%BB%8Dc%20detail/800/600\", \"https://picsum.photos/seed/Gi%C6%B0%E1%BB%9Dng%20t%E1%BA%A7ng%20tr%E1%BA%BB%20em%20t%C3%ADch%20h%E1%BB%A3p%20b%C3%A0n%20h%E1%BB%8Dc%20showroom/800/600\"]','{\"An toàn\": \"Bo góc, lan can cao, thang rộng\", \"Vật liệu\": \"MDF chuẩn E1 phủ Melamine\", \"Đơn giá tham khảo\": \"24.000.000 - 42.000.000 đ/bộ\", \"Độ tuổi phù hợp\": \"6 - 14 tuổi\"}',8,1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5G54PCMS572VR6RST3K','Cụm bàn làm việc module 6 người','cum-ban-lam-viec-module-6-nguoi','01M167S5D74HQ6Q4M2G8ZQHN0A','Cụm bàn linh hoạt cho team vận hành, kế toán, sale hoặc kỹ thuật.','Khung sắt sơn tĩnh điện, mặt bàn MFC chống trầy, vách ngăn nỉ hoặc mica mờ. Hệ máng điện và lỗ chờ dây giúp mặt bàn sạch, dễ quản lý thiết bị.\n\nCó thể mở rộng theo dãy 4, 6, 8 người và đồng bộ tủ phụ cá nhân.','https://picsum.photos/seed/office%20workstation%20desk/800/600','[\"https://picsum.photos/seed/office%20workstation%20desk/800/600\", \"https://picsum.photos/seed/C%E1%BB%A5m%20b%C3%A0n%20l%C3%A0m%20vi%E1%BB%87c%20module%206%20ng%C6%B0%E1%BB%9Di%20detail/800/600\", \"https://picsum.photos/seed/C%E1%BB%A5m%20b%C3%A0n%20l%C3%A0m%20vi%E1%BB%87c%20module%206%20ng%C6%B0%E1%BB%9Di%20showroom/800/600\"]','{\"Phụ kiện\": \"Máng điện, vách ngăn, hộc di động\", \"Vật liệu\": \"Khung sắt, MFC phủ Melamine\", \"Đơn giá tham khảo\": \"2.600.000 - 4.200.000 đ/chỗ\", \"Kích thước mỗi chỗ\": \"1200x600mm hoặc 1400x700mm\"}',9,1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5GC2NF7CJEWFXTAYW29','Tủ hồ sơ cao kịch trần cho văn phòng','tu-ho-so-cao-kich-tran-cho-van-phong','01M167S5D74HQ6Q4M2G8ZQHN0A','Tăng dung lượng lưu trữ hồ sơ nhưng giữ mặt bằng làm việc gọn.','Tủ chia khoang hồ sơ A4, khoang khóa riêng và khoang mở trưng bày. Cánh dưới kín chống bụi, cánh trên kính hoặc mở để giảm cảm giác nặng.\n\nPhù hợp văn phòng luật, kế toán, công ty dịch vụ và phòng hành chính.','https://picsum.photos/seed/office%20storage%20cabinet/800/600','[\"https://picsum.photos/seed/office%20storage%20cabinet/800/600\", \"https://picsum.photos/seed/T%E1%BB%A7%20h%E1%BB%93%20s%C6%A1%20cao%20k%E1%BB%8Bch%20tr%E1%BA%A7n%20cho%20v%C4%83n%20ph%C3%B2ng%20detail/800/600\", \"https://picsum.photos/seed/T%E1%BB%A7%20h%E1%BB%93%20s%C6%A1%20cao%20k%E1%BB%8Bch%20tr%E1%BA%A7n%20cho%20v%C4%83n%20ph%C3%B2ng%20showroom/800/600\"]','{\"Chiều cao\": \"Theo trần thực tế\", \"Vật liệu\": \"MFC/MDF chống ẩm\", \"Tải trọng kệ\": \"25 - 35kg/khoang\", \"Đơn giá tham khảo\": \"2.400.000 - 3.600.000 đ/m2\"}',10,1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5GKFAWAX3FAZ7RHDG6N','Bộ bàn ghế nhà hàng khung gỗ nệm simili','bo-ban-ghe-nha-hang-khung-go-nem-simili','01M167S5DE0T9M3B9EDX3TKXVN','Cấu hình bền cho nhà hàng gia đình, quán lẩu nướng và khách sạn nhỏ.','Ghế khung gỗ cao su hoặc ash, nệm mút D40 bọc simili dễ lau. Bàn dùng mặt laminate hoặc đá nhân tạo tùy concept và cường độ sử dụng.\n\nThiết kế ưu tiên vệ sinh nhanh, dễ thay nệm và đồng bộ màu nhận diện thương hiệu.','https://picsum.photos/seed/restaurant%20dining%20furniture/800/600','[\"https://picsum.photos/seed/restaurant%20dining%20furniture/800/600\", \"https://picsum.photos/seed/B%E1%BB%99%20b%C3%A0n%20gh%E1%BA%BF%20nh%C3%A0%20h%C3%A0ng%20khung%20g%E1%BB%97%20n%E1%BB%87m%20simili%20detail/800/600\", \"https://picsum.photos/seed/B%E1%BB%99%20b%C3%A0n%20gh%E1%BA%BF%20nh%C3%A0%20h%C3%A0ng%20khung%20g%E1%BB%97%20n%E1%BB%87m%20simili%20showroom/800/600\"]','{\"Vật liệu\": \"Gỗ cao su/ash, nệm simili\", \"Ứng dụng\": \"Nhà hàng, cafe, khách sạn\", \"Đơn giá tham khảo\": \"1.450.000 - 3.200.000 đ/ghế\", \"Tần suất sử dụng\": \"Cao\"}',11,1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5GS4TBJT98T3WRV280S','Quầy thu ngân kết hợp kệ trưng bày','quay-thu-ngan-ket-hop-ke-trung-bay','01M167S5DMVQYXC4FP6BC3PQCN','Quầy bán lẻ có khoang máy POS, máy in hóa đơn và tủ khóa nhân viên.','Quầy được chia mặt giao dịch, mặt thao tác nhân viên và khoang kỹ thuật để giấu dây. Mặt ngoài có thể ốp lam, đá, acrylic hoặc logo phát sáng.\n\nPhù hợp showroom nội thất, spa, cửa hàng thời trang, mỹ phẩm và vật liệu hoàn thiện.','https://picsum.photos/seed/retail%20cashier%20counter/800/600','[\"https://picsum.photos/seed/retail%20cashier%20counter/800/600\", \"https://picsum.photos/seed/Qu%E1%BA%A7y%20thu%20ng%C3%A2n%20k%E1%BA%BFt%20h%E1%BB%A3p%20k%E1%BB%87%20tr%C6%B0ng%20b%C3%A0y%20detail/800/600\", \"https://picsum.photos/seed/Qu%E1%BA%A7y%20thu%20ng%C3%A2n%20k%E1%BA%BFt%20h%E1%BB%A3p%20k%E1%BB%87%20tr%C6%B0ng%20b%C3%A0y%20showroom/800/600\"]','{\"Tích hợp\": \"POS, máy in, két nhỏ, LED logo\", \"Vật liệu\": \"MDF chống ẩm, Laminate, đá nhân tạo\", \"Đơn giá tham khảo\": \"12.000.000 - 38.000.000 đ/bộ\", \"Chiều dài phổ biến\": \"1.6m - 2.8m\"}',12,1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5H9P4V7DXWTNX2B99Q2','Tủ thờ gỗ Sồi phong cách hiện đại','tu-tho-go-soi-phong-cach-hien-dai','01M167S5DV5D12D11X43VY0480','Mẫu tủ thờ gọn, trang nghiêm cho chung cư và nhà phố.','Tủ thờ dùng gỗ Sồi hoặc gỗ Gõ tùy ngân sách, kiểu dáng tiết chế chi tiết chạm khắc để hợp căn hộ hiện đại. Có ngăn kéo đồ lễ, khoang chứa và vách hậu CNC.\n\nKích thước được tư vấn theo không gian, hướng đặt và khoảng thông thoáng phía trên bàn thờ.','https://picsum.photos/seed/modern%20wooden%20altar%20cabinet/800/600','[\"https://picsum.photos/seed/modern%20wooden%20altar%20cabinet/800/600\", \"https://picsum.photos/seed/T%E1%BB%A7%20th%E1%BB%9D%20g%E1%BB%97%20S%E1%BB%93i%20phong%20c%C3%A1ch%20hi%E1%BB%87n%20%C4%91%E1%BA%A1i%20detail/800/600\", \"https://picsum.photos/seed/T%E1%BB%A7%20th%E1%BB%9D%20g%E1%BB%97%20S%E1%BB%93i%20phong%20c%C3%A1ch%20hi%E1%BB%87n%20%C4%91%E1%BA%A1i%20showroom/800/600\"]','{\"Vật liệu\": \"Gỗ Sồi/Gõ tự nhiên\", \"Ứng dụng\": \"Chung cư, nhà phố\", \"Hoàn thiện\": \"Sơn PU mờ\", \"Đơn giá tham khảo\": \"14.000.000 - 45.000.000 đ/bộ\"}',13,1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5JPSC2X6NFM3P1JV5VM','Combo phụ kiện bếp Eurogold tiêu chuẩn','combo-phu-kien-bep-eurogold-tieu-chuan','01M167S5E1GY0F3WFJPSE0KHRF','Bộ phụ kiện nền tảng cho tủ bếp mới, cân bằng giữa chi phí và trải nghiệm.','Combo gồm giá xoong nồi, giá bát nâng hạ hoặc cố định, thùng gạo, thùng rác âm, khay chia thìa dĩa và kệ gia vị. Kích thước chọn theo khoang tủ thực tế.\n\nĐội thi công kiểm tra ray, độ vuông khoang và tải trọng trước khi lắp để tránh kẹt hoặc xệ sau sử dụng.','https://picsum.photos/seed/kitchen%20cabinet%20accessories%20hardware/800/600','[\"https://picsum.photos/seed/kitchen%20cabinet%20accessories%20hardware/800/600\", \"https://picsum.photos/seed/Combo%20ph%E1%BB%A5%20ki%E1%BB%87n%20b%E1%BA%BFp%20Eurogold%20ti%C3%AAu%20chu%E1%BA%A9n%20detail/800/600\", \"https://picsum.photos/seed/Combo%20ph%E1%BB%A5%20ki%E1%BB%87n%20b%E1%BA%BFp%20Eurogold%20ti%C3%AAu%20chu%E1%BA%A9n%20showroom/800/600\"]','{\"Bảo hành\": \"12 - 24 tháng\", \"Chất liệu\": \"Inox 304/201 tùy hạng mục\", \"Thương hiệu\": \"Eurogold hoặc tương đương\", \"Đơn giá tham khảo\": \"8.000.000 - 22.000.000 đ/combo\"}',14,1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5K77N0MPXXVD4RYHZWC','Gói nội thất căn hộ 2 phòng ngủ','goi-noi-that-can-ho-2-phong-ngu','01M167S5E7VZHC4427MTTCHZT1','Thiết kế, sản xuất và lắp đặt đồng bộ cho căn hộ 55-75m2.','Gói bao gồm tủ bếp, kệ TV, sofa cơ bản, bàn ăn, 2 giường, 2 tủ áo, bàn học/bàn làm việc và rèm. Phương án phù hợp gia đình trẻ cần dọn vào ở nhanh.\n\nKhách hàng nhận layout, phối màu, báo giá theo từng hạng mục và tiến độ sản xuất trước khi chốt hợp đồng.','https://picsum.photos/seed/two%20bedroom%20apartment%20interior%20package/800/600','[\"https://picsum.photos/seed/two%20bedroom%20apartment%20interior%20package/800/600\", \"https://picsum.photos/seed/G%C3%B3i%20n%E1%BB%99i%20th%E1%BA%A5t%20c%C4%83n%20h%E1%BB%99%202%20ph%C3%B2ng%20ng%E1%BB%A7%20detail/800/600\", \"https://picsum.photos/seed/G%C3%B3i%20n%E1%BB%99i%20th%E1%BA%A5t%20c%C4%83n%20h%E1%BB%99%202%20ph%C3%B2ng%20ng%E1%BB%A7%20showroom/800/600\"]','{\"Bảo hành\": \"24 tháng\", \"Diện tích phù hợp\": \"55 - 75m2\", \"Ngân sách tham khảo\": \"145.000.000 - 260.000.000 đ\", \"Thời gian triển khai\": \"25 - 35 ngày\"}',15,1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area_sqm` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `thumbnail_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gallery_urls` json DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_projects_slug` (`slug`),
  KEY `IDX_projects_province` (`province`),
  KEY `IDX_projects_featured` (`is_featured`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES ('01M167S5KJ35JD4XT4NSRRCRWD','Căn hộ 2PN Vinhomes Smart City','can-ho-2pn-vinhomes-smart-city','Hà Nội','Tây Mỗ, Nam Từ Liêm','68m2','Thi công trọn gói căn hộ 2 phòng ngủ cho gia đình trẻ, ưu tiên công năng lưu trữ và màu gỗ sáng.\n\nHạng mục gồm tủ bếp chữ L, kệ TV treo, vách sofa, tủ áo kịch trần, giường hộp và bàn học trẻ em. Tổng thời gian sản xuất lắp đặt 28 ngày.','https://picsum.photos/seed/small%20apartment%20vietnam%20interior/800/600','[\"https://picsum.photos/seed/apartment%20living%20room/800/600\", \"https://picsum.photos/seed/apartment%20kitchen/800/600\", \"https://picsum.photos/seed/apartment%20bedroom/800/600\"]',1,1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5KTXN1Z2ZJSK9QFD8VG','Nhà phố 4 tầng Phúc Thọ','nha-pho-4-tang-phuc-tho','Hà Nội','Vân Nam, Phúc Thọ','185m2','Dự án nhà phố hoàn thiện nội thất theo từng tầng: khách-bếp, phòng ngủ bố mẹ, hai phòng con và phòng thờ.\n\nGia chủ chọn gỗ Sồi cho các điểm nhấn chính, kết hợp MDF chống ẩm cho hệ tủ lớn để cân bằng ngân sách.','https://picsum.photos/seed/vietnam%20townhouse%20interior/800/600','[\"https://picsum.photos/seed/townhouse%20kitchen/800/600\", \"https://picsum.photos/seed/townhouse%20bedroom/800/600\", \"https://picsum.photos/seed/wood%20altar%20room/800/600\"]',2,1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5M140SAQ7G4Q9ARNKM1','Biệt thự Ecopark phong cách Contemporary','biet-thu-ecopark-phong-cach-contemporary','Hưng Yên','Khu đô thị Ecopark','320m2','Không gian biệt thự dùng bảng màu trung tính, gỗ óc chó và đá vân nhẹ. Thiết kế tập trung vào phòng khách lớn, bếp đảo và master suite.\n\nCác hệ tủ được sản xuất theo kích thước thực tế để xử lý dầm, cột và hệ điều hòa âm trần.','https://picsum.photos/seed/villa%20walnut%20contemporary%20interior/800/600','[\"https://picsum.photos/seed/villa%20living%20room/800/600\", \"https://picsum.photos/seed/villa%20kitchen%20island/800/600\", \"https://picsum.photos/seed/villa%20master%20bedroom/800/600\"]',3,1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5MAXDFGZ7FZ29MEBTJA','Văn phòng công ty xây dựng tại Cầu Giấy','van-phong-cong-ty-xay-dung-tai-cau-giay','Hà Nội','Duy Tân, Cầu Giấy','240m2','Fit-out văn phòng 45 nhân sự gồm khu làm việc mở, hai phòng họp, phòng giám đốc, pantry và tủ hồ sơ.\n\nVật liệu MFC chống trầy, khung sắt sơn tĩnh điện và hệ điện âm bàn giúp không gian vận hành gọn.','https://picsum.photos/seed/office%20fitout%20interior/800/600','[\"https://picsum.photos/seed/open%20office%20workstation/800/600\", \"https://picsum.photos/seed/meeting%20room%20interior/800/600\", \"https://picsum.photos/seed/office%20pantry/800/600\"]',4,1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5MHH8Z5PGVQNS1C09PY','Nhà hàng lẩu nướng tại Mỹ Đình','nha-hang-lau-nuong-tai-my-dinh','Hà Nội','Mỹ Đình, Nam Từ Liêm','210m2','Thi công bàn ghế, vách ngăn, quầy thu ngân và hệ tủ phụ cho nhà hàng có công suất phục vụ cao.\n\nBề mặt vật liệu ưu tiên khả năng lau chùi, chịu nhiệt và dễ thay thế khi khai thác lâu dài.','https://picsum.photos/seed/bbq%20restaurant%20interior/800/600','[\"https://picsum.photos/seed/restaurant%20booth%20seating/800/600\", \"https://picsum.photos/seed/restaurant%20cashier%20counter/800/600\", \"https://picsum.photos/seed/restaurant%20dining%20room/800/600\"]',5,1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5MQJN8WSGT0BSE6YZQ3','Showroom vật liệu hoàn thiện Hoài Đức','showroom-vat-lieu-hoan-thien-hoai-duc','Hà Nội','Hoài Đức','160m2','Thiết kế showroom trưng bày mẫu gỗ, đá, thiết bị vệ sinh và phụ kiện nội thất. Lối đi được tính theo hành trình tư vấn khách hàng.\n\nQuầy tư vấn tích hợp khoang catalogue, máy POS và tủ khóa hồ sơ hợp đồng.','https://picsum.photos/seed/material%20showroom%20interior/800/600','[\"https://picsum.photos/seed/retail%20display%20shelves/800/600\", \"https://picsum.photos/seed/material%20sample%20wall/800/600\", \"https://picsum.photos/seed/showroom%20consultation%20desk/800/600\"]',6,1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5MX23P9K6KYWRSWA7ME','Homestay Ba Vì 6 phòng','homestay-ba-vi-6-phong','Hà Nội','Ba Vì','280m2','Dự án homestay dùng vật liệu bền, dễ thay thế và phong cách mộc hiện đại để phù hợp khai thác lưu trú.\n\nCác phòng dùng giường hộp, tủ mở, bàn trang điểm nhỏ và vách đầu giường tạo điểm nhận diện.','https://picsum.photos/seed/homestay%20bedroom%20interior/800/600','[\"https://picsum.photos/seed/homestay%20room/800/600\", \"https://picsum.photos/seed/wood%20cabin%20interior/800/600\", \"https://picsum.photos/seed/boutique%20hotel%20bedroom/800/600\"]',7,1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5NS0CR8WNEST23G2FSA','Căn hộ studio cho thuê tại Hà Đông','can-ho-studio-cho-thue-tai-ha-dong','Hà Nội','Văn Quán, Hà Đông','36m2','Căn hộ studio nhỏ được xử lý bằng giường có hộc, tủ bếp chữ I, bàn ăn gấp và tủ áo cánh lùa.\n\nMục tiêu là tăng công năng nhưng vẫn giữ chi phí phù hợp mô hình cho thuê dài hạn.','https://picsum.photos/seed/studio%20apartment%20space%20saving%20interior/800/600','[\"https://picsum.photos/seed/studio%20kitchen/800/600\", \"https://picsum.photos/seed/murphy%20bed%20interior/800/600\", \"https://picsum.photos/seed/small%20wardrobe/800/600\"]',8,1,0,'2026-08-29 07:47:08','2026-08-29 07:47:08');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refresh_tokens`
--

DROP TABLE IF EXISTS `refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refresh_tokens` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `revoked_at` timestamp NULL DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `IDX_refresh_tokens_user_id` (`user_id`),
  CONSTRAINT `FK_refresh_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refresh_tokens`
--

LOCK TABLES `refresh_tokens` WRITE;
/*!40000 ALTER TABLE `refresh_tokens` DISABLE KEYS */;
INSERT INTO `refresh_tokens` VALUES ('01M169M21H7AH9GZG7SN8QCFM4','01M167S5C10YMBEYSDWJHFYKJ8','$2b$12$IPAeoU6med42XXGm7eTQJeUb1jLUNksaIXl5uFRiN5/RivYcZB9xu','2026-09-05 08:19:18',NULL,'::ffff:172.19.0.4','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-08-29 08:19:18');
/*!40000 ALTER TABLE `refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` tinyint NOT NULL DEFAULT '5',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` VALUES ('01M167S5RA2GCK8D9FJ2AMREEQ','Anh Hùng','Phúc Thọ, Hà Nội',5,'Tủ bếp lắp đúng bản vẽ, phụ kiện chạy êm. Đội thi công xử lý phần hộp kỹ thuật rất gọn nên bếp nhìn rộng hơn dự kiến.','https://picsum.photos/seed/portrait%20Anh%20H%C3%B9ng/800/600',1,1,1,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5RFD2Y1YFZ63TYCQYAY','Chị Mai Anh','Nam Từ Liêm, Hà Nội',5,'Căn hộ 2 phòng ngủ được bàn giao đúng hẹn. Phần tủ áo và giường hộp chứa được nhiều đồ, màu sắc giống phối cảnh.','https://picsum.photos/seed/portrait%20Ch%E1%BB%8B%20Mai%20Anh/800/600',1,1,2,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5RPFGZ809HVWMX665WV','Anh Quang','Cầu Giấy, Hà Nội',5,'Văn phòng mới gọn hơn nhiều, dây điện bàn làm việc được giấu sạch. Nhân viên dùng một tháng chưa có vấn đề phát sinh.','https://picsum.photos/seed/portrait%20Anh%20Quang/800/600',1,1,3,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5RVYVEX8A6QA0WDFRZ6','Chị Hạnh','Hoài Đức, Hà Nội',5,'Showroom có quầy tư vấn và kệ mẫu rất tiện. Khách vào xem vật liệu dễ hình dung hơn so với cách trưng bày cũ.','https://picsum.photos/seed/portrait%20Ch%E1%BB%8B%20H%E1%BA%A1nh/800/600',1,0,4,'2026-08-29 07:47:08','2026-08-29 07:47:08'),('01M167S5S21HNAJJK4B48CR4YY','Anh Tuấn','Ba Vì, Hà Nội',5,'Homestay dùng nội thất đơn giản nhưng chắc. Các phòng đồng bộ, dễ vệ sinh và thay đồ khi vận hành.','https://picsum.photos/seed/portrait%20Anh%20Tu%E1%BA%A5n/800/600',1,0,5,'2026-08-29 07:47:08','2026-08-29 07:47:08');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_changelog`
--

DROP TABLE IF EXISTS `schema_changelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_changelog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(20) NOT NULL COMMENT 'VD: 1.0.0, 1.1.0',
  `filename` varchar(255) NOT NULL COMMENT 'VD: 001__add_column.sql',
  `description` varchar(255) NOT NULL DEFAULT '',
  `applied_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `applied_by` varchar(50) NOT NULL DEFAULT 'ci' COMMENT 'ci hoac manual',
  `checksum` varchar(64) DEFAULT NULL COMMENT 'SHA256 cua file SQL',
  `execution_ms` int DEFAULT NULL COMMENT 'Thoi gian chay (ms)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_version_file` (`version`,`filename`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_changelog`
--

LOCK TABLES `schema_changelog` WRITE;
/*!40000 ALTER TABLE `schema_changelog` DISABLE KEYS */;
INSERT INTO `schema_changelog` VALUES (1,'1.0.0','001__initial_schema.sql','initial schema','2026-08-29 07:43:42','ci','9e8c7fc3330ceef3206415d32891858b372ce590dff777ddc9fbdb99a59c2722',NULL),(2,'1.0.0','002__create_app_logs.sql','create app logs','2026-08-29 07:43:46','ci','38b7ee1b377e11ce7c8a3c6639da0c07a3117f49241990deb54884de80b04d31',NULL),(3,'1.0.0','003__add_category_enum_values.sql','add category enum values','2026-08-29 07:43:51','ci','55aabfbd3ddbc9b58ff3b13ed0d91ee214bd2d0e626625afa7ce2a169a269a7e',NULL),(4,'1.1.0','001__add_scheduled_publish_at.sql','add scheduled publish at','2026-08-29 07:43:55','ci','884f67c3cec29ff7e6cf2aec73fc9a933dfb4568cda4ea793f7cae456f4d7eaa',NULL),(5,'1.2.0','001__rebuild_all_tables.sql','rebuild all tables','2026-08-29 07:44:01','ci','2722a02b86a9fe55858178420327a08e5b0c26f7b4ac2847ea063830a4878c50',NULL);
/*!40000 ALTER TABLE `schema_changelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_config`
--

DROP TABLE IF EXISTS `site_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_config` (
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'string',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_config`
--

LOCK TABLES `site_config` WRITE;
/*!40000 ALTER TABLE `site_config` DISABLE KEYS */;
INSERT INTO `site_config` VALUES ('address','Vân Nam - Phúc Thọ - Hà Nội','string','2026-08-29 07:47:08'),('admin_email','duymanhnoithat@gmail.com','string','2026-08-29 07:47:08'),('email_contact','duymanhnoithat@gmail.com','string','2026-08-29 07:47:08'),('facebook_url','https://facebook.com/duymanhnoithat','string','2026-08-29 07:47:08'),('google_maps_embed_url','https://maps.google.com/maps?q=V%C3%A2n+Nam+Ph%C3%BAc+Th%E1%BB%8D+H%C3%A0+N%E1%BB%99i&t=&z=14&ie=UTF8&iwloc=&output=embed','string','2026-08-29 07:47:08'),('hotline','094.872.8091','string','2026-08-29 07:47:08'),('meta_description','Xưởng nội thất Duy Mạnh tại Phúc Thọ, Hà Nội: tủ bếp, căn hộ, nhà phố, văn phòng, showroom, nhà hàng và nội thất trọn gói theo đo đạc thực tế.','string','2026-08-29 07:47:08'),('meta_title','Nội Thất Duy Mạnh - Thiết kế, sản xuất và thi công nội thất Hà Nội','string','2026-08-29 07:47:08'),('resend_from','no-reply@duymanhnoithat.vn','string','2026-08-29 07:47:08'),('site_name','Nội Thất Duy Mạnh','string','2026-08-29 07:47:08'),('working_hours','8h00 - 18h00, Thứ 2 - Chủ nhật','string','2026-08-29 07:47:08'),('zalo_url','https://zalo.me/0948728091','string','2026-08-29 07:47:08');
/*!40000 ALTER TABLE `site_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typeorm_migrations`
--

DROP TABLE IF EXISTS `typeorm_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `typeorm_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` bigint NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typeorm_migrations`
--

LOCK TABLES `typeorm_migrations` WRITE;
/*!40000 ALTER TABLE `typeorm_migrations` DISABLE KEYS */;
INSERT INTO `typeorm_migrations` VALUES (1,1749200000000,'NoiThat2026InitialSchema1749200000000'),(2,1749400000000,'AddLogsAnalyticsPages1749400000000'),(3,1750500000000,'AddMissingMediaColumns1750500000000');
/*!40000 ALTER TABLE `typeorm_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('super_admin','admin','editor','viewer') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewer',
  `status` enum('active','inactive','banned') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `refresh_token_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` char(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_by` char(26) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_users_email` (`email`),
  KEY `IDX_users_role` (`role`),
  KEY `IDX_users_status` (`status`),
  KEY `IDX_users_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('01M167S5C10YMBEYSDWJHFYKJ8','Admin Duy Mạnh','admin@duymanhnoithat.vn','$2b$12$gGU2h7iJqAThbArLWA./0.Cokee8l.lf7i0QM7Mz4Ac844MpJ1b7G',NULL,NULL,'super_admin','active',NULL,'2026-08-29 08:19:18','2026-08-29 07:47:08','2026-08-29 08:19:18',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videos` (
  `id` char(26) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `video_type` enum('youtube','upload') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'youtube',
  `youtube_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `thumbnail_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videos`
--

LOCK TABLES `videos` WRITE;
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'noithat2026'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-29 21:04:00
